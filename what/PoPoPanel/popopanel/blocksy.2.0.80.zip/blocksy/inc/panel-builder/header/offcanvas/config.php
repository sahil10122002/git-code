<?php

$config = [
	'name' => __('Offcanvas', 'blocksy')
];