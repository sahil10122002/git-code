<?php

$config = [
	'name' => __('Off Canvas Logo', 'blocksy'),
	'devices' => ['mobile'],
	'allowed_in' => ['offcanvas'],
	'selective_refresh' => [
		'custom_logo',
		'inline_svg_logos'
	],
];
