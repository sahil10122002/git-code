<?php

$config = [
	'name' => __('Bottom Row', 'blocksy'),
];

