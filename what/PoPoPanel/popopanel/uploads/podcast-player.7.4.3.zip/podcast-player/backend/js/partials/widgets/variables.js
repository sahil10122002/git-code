let ppAdminVariables = {
	ajaxtimeout: null,
};
export default ppAdminVariables;