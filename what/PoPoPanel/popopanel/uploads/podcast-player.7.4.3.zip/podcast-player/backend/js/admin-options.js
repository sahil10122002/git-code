import DomManipulation from './partials/options/dom';
import FeedEditor from './partials/options/feededit';
import Reviews from './partials/options/reviews';

new DomManipulation();
new FeedEditor();
new Reviews();